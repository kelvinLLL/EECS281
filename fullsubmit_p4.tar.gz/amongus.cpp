// Project Identifier: ​9B734EC0C043C5A836EA0EBE4BEFEA164490B2C7
#include <iostream>
#include <deque>
#include <vector>
#include <iostream>
#include <algorithm> // std::sort
#include <getopt.h>
#include <string>    // needed for VS
#include <limits>
#include <math.h>
#include <iomanip>

using namespace std;

struct point{
    int x = 0;
    int y = 0;
    int ind = 0;
    char state = ' '; // l for lab, d for decon... o for outer.
};
class  Among_us{
public:

    Among_us() = default;

    void get_options(int argc, char** argv);

    void read();

    void run();

    double prim(vector<point>& points_check);

private:
    bool is_MST = false;
    bool is_Fast = false;
    bool is_Opt = false;

    // A
    bool is_o = false;
    bool is_l = false;
    bool is_d = false;
    vector<bool> kv;
    vector<int> pv;
    vector<int> out_seq;
    int num_points = 0;
    int find_small();
    vector<point> points;
    vector<double> dv;
    double distance(point &a, point& b);

    // B
    //void pre_order(int index);
    void fast();

    // C
    bool promising(size_t length);
    void genPerms(size_t permlength);
    double Weight = 0;
    double lower = numeric_limits<double>::infinity();
    // TRY
    vector<point> temp;
    vector<vector<double> > adj;
    vector<int> record;
    //int cnt = 0;
};

int main(int argc, char **argv) {
    std::ios_base::sync_with_stdio(false);
    cout << std::setprecision(2); //Always show 2 decimal place
    cout << std::fixed; //Disable scientific notation for large numbers
    Among_us among_;
    among_.read();
    among_.get_options(argc, argv);
    among_.run();

    return 0;
}

void Among_us::get_options(int argc, char **argv) {
    int option_index = 0, option = 0;

    // Don't display getopt error messages about options ?
    opterr = false;

    struct option longOpts[] = {{ "mode"   , required_argument   , nullptr   , 'm'},
                                { "help"   , no_argument   , nullptr   , 'h'},
                                { nullptr   , 0              , nullptr   , '\0'}
    };

    while((option = getopt_long(argc, argv, "m:h", longOpts, &option_index)) != -1){
        switch (option){
            case 'm':
                if(optarg[0] == 'M'){
                    is_MST = true;
                }
                else if(optarg[0] == 'F'){
                    is_Fast = true;
                }
                else if(optarg[0] == 'O'){
                    is_Opt = true;
                }
                else{
                    exit(1); // error: wrong argument.
                }
                break;
            case 'h':
                // output any things.
                exit(0);
        }
    } // end while.
}

void Among_us::run() {
    if(is_MST){
        if(is_l && is_o && !is_d){
            cerr<<"Cannot construct MST"<<endl;
            exit(1);
        }
        double weight = 0;
        weight = prim(points);
        cout<<weight<<'\n';
        int begin, end;
        for(int i = 1; i < (int)pv.size(); ++i){
            begin = pv[i];
            end = i;
            if(begin > end){
                swap(begin, end);
            }
            cout<<begin<<' '<<end<<'\n';
        }
    }
    else if(is_Fast){
        fast();
        cout<<Weight<<'\n';
        out_seq.pop_back();
        for(const auto&i: out_seq){
            cout<<i<<' ';
        }
        cout<<'\n';
    }
    else if(is_Opt){
        adj.resize((unsigned long long)num_points);
        record.resize((unsigned long long)num_points);
        for(size_t i = 0; i < (unsigned long long)num_points; ++i){
            adj[i].resize((unsigned long long)num_points);
            for(size_t j = 0; j < (unsigned long long)num_points; ++j){
                if(i != j){
                    adj[i][j] = distance(points[i], points[j]);
                }
            }
        }
        fast();
        lower = Weight;
        Weight = 0;
        for(size_t i = 0; i < (unsigned long long)num_points; ++i){
            record[i] = out_seq[i];
        }
        // TRY
        vector<point> temm = points;
        for(size_t i = 0; i < (unsigned long long)num_points; ++i){
            points[i] = temm[out_seq[i]];
        }
        // RUN
        genPerms(1);
        cout<<lower<<'\n';
        for(const auto& i:record){
            cout<<i<<' ';
        }
        cout<<'\n';
        //cout<<cnt;
    }
}

void Among_us::read() {
    cin>>num_points;
    points.reserve((unsigned long long)num_points);
    int x, y;
    for(int i = 0; i < num_points; ++i){
        cin>>x>>y;
        cin.get();
        points.push_back(point{x,y,i});
    }
}

double Among_us::prim(vector<point> &points_check) {
    size_t N = points_check.size();
    kv.clear();      pv.clear();     dv.clear();
    kv.reserve(N);   pv.reserve(N);  dv.reserve(N);
    if(is_MST){ // initial state vector.
        for(size_t i = 0; i < N; ++i){
            if(points_check[i].x < 0 && points_check[i].y < 0){
                points_check[i].state = 'l';
                is_l = true;
            }
            else if((points_check[i].x == 0 && points_check[i].y <= 0) || (points_check[i].y == 0 && points_check[i].x <= 0) ){
                points_check[i].state = 'd';
                is_d = true;
            }
            else{
                points_check[i].state = 'o';
                is_o = true;
            }
        }
    }
    // initialization.
    for(size_t i = 0; i < N; ++i){
        kv.emplace_back(false);
        pv.emplace_back(-1);
        dv.emplace_back(numeric_limits<double>::infinity());
    }
    dv[0] = 0;  pv[0] = -1;
    // Run
    int index = find_small();
    double dist;
    double total = 0;
    while(index != -1){
        kv[index] = true;
        total += dv[index];
        for(size_t i = 0; i < N; ++i){
            if(!kv[i]){ // if kv = false
                if(is_Opt){
                    dist = adj[points_check[index].ind][points_check[i].ind];
                }
                else{
                    dist = distance(points_check[index], points_check[i]);
                }
                if(dv[i] > dist){ // if smaller.
                    dv[i] = dist;
                    pv[i] = index;
                }
            }
        }
        index = find_small();
    }
    return total;
}

double Among_us::distance(point &a, point &b) {
    if(is_MST){
        if((a.state == 'l' && b.state == 'o') || (a.state == 'o' && b.state == 'l')){
            return numeric_limits<double>::infinity();
        }
    }
    return sqrt(((double)a.x - (double)b.x)*((double)a.x - (double)b.x) + ((double)a.y - (double)b.y)*((double)a.y - (double)b.y));
}

int Among_us::find_small() {
    int ans = -1;
    double small = numeric_limits<double>::infinity();
    for(size_t i = 0; i < kv.size(); ++i){
        if(!kv[i]){
            if(small > dv[i]){
                small = dv[i];
                ans = (int) i;
            }
        }
    }
    return ans;
}

/*
void Among_us::pre_order(int index) {
    out_seq.push_back(index);
    for(size_t i = 0; i < pv.size(); ++i){
        if(pv[i] == index){
            pre_order((int)i);
        }
    }
}*/

void Among_us::fast() {
    out_seq.reserve((unsigned long long )num_points+1);
    out_seq.push_back(0);
    out_seq.push_back(0);
    if(num_points == 1){
        return;
    }
    else if(num_points == 2){
        out_seq.push_back(0);
        out_seq[1] = 1;
        Weight += 2 * distance(points[0], points[1]);
        return;
    }
    out_seq.push_back(0);
    out_seq.push_back(0);
    out_seq[1] = 1;
    out_seq[2] = 2;
    Weight += distance(points[0], points[1]);
    Weight += distance(points[0], points[2]);
    Weight += distance(points[1], points[2]);
    double small, tem;
    auto it = out_seq.begin();
    for(size_t i = 3; i < (unsigned long long)num_points; ++i){
        small = numeric_limits<double>::infinity();
        for(auto j = out_seq.begin(); j < out_seq.end()-1; ++j){
            tem = distance(points[*j], points[i]) + distance(points[*(j+1)], points[i]) - distance(points[*j], points[*(j+1)]);
            if(tem < small){
                small = tem;
                it = j+1;
            }
        }
        out_seq.insert(it,(int)i);
        Weight += small;
    }

}

void Among_us::genPerms(size_t permlength) {
    //++cnt;
    if(permlength == (unsigned long long)num_points){
        Weight += adj[0][points[num_points-1].ind];
        if(lower > Weight){
            lower = Weight;
            for(size_t i = 0; i < (unsigned long long)num_points; ++i){
                record[i] = points[i].ind;
            }
        }
        Weight -= adj[0][points[num_points-1].ind];
        return;
    }
    if(num_points-permlength > 4 && !promising(permlength)) return;
    for(size_t i = permlength; i < (unsigned long long)num_points; ++i){
        swap(points[permlength], points[i]);
        Weight += adj[points[permlength-1].ind][points[permlength].ind];
        genPerms(permlength+1);
        Weight -= adj[points[permlength-1].ind][points[permlength].ind];
        swap(points[permlength], points[i]);
    }
}

bool Among_us::promising(size_t length) {
    temp.assign(points.begin()+length, points.end());
    double mst = prim(temp);
    double lower1 = numeric_limits<double>::infinity();
    double lower2 = numeric_limits<double>::infinity();
    double temp1,temp2;
    for(size_t j = length; j < (unsigned long long)num_points; ++j) {
        temp1 = adj[0][points[j].ind];
        temp2 = adj[points[length - 1].ind][points[j].ind];
        lower1 = (temp1 < lower1) ? temp1 : lower1;
        lower2 = (temp2 < lower2) ? temp2 : lower2;
    }


    return (Weight + lower1 + lower2 + mst < lower);

}

// Project Identifier: 50EB44D3F029ED934858FFFCEAC3547C68768FC9
// Created by 26673 on 2020/9/14.
//
#include <deque>
#include <vector>
#include <iostream>
#include <algorithm> // std::sort
#include <getopt.h>
#include <string>    // needed for VS
/*
#include<stdio.h>
#include<sys/time.h>
#include<unistd.h>
*/
typedef struct {
    std::string content;
    bool status = false; // 1 if used, 0 if not used.
    int index = -1;
    int prev = 0;
} Word;

class Dictionary_{

public:

    Dictionary_() = default;

    // Read in the file.
    void read_();

    // Read and process command line arguments.
    void get_options(int argc, char** argv);

    void run();

    void output();
private:
    //int nt = 0;
    // the dictionary that contains all the words.
    std::vector<Word> Dict;

    // The container used in algorithm.
    std::deque<int> container;

    // Judge whether it can be transformed.
    bool judge(Word& dest);

    // Judge only for no l change.
    bool judge_nol(Word& dest);


    void simple_output(int temp);


    void modi_output(int temp);


    void modi_judge(std::string &origin, std::string &target);

    int total_num = 0;

    // Status that the letterman can use.
    bool is_simple = true;
    bool is_stack = false;
    bool is_queue = false;
    bool c = false;
    bool p = false;
    bool l = false;
    bool is_word = true; // true if it is word.
    std::string begin_w;
    std::string end_w;
    Word curr_w;

    int total_changes = 1;
    //int total_searches = 1;
    bool can_reach = false;

};

int main(int argc, char** argv){
    std::ios_base::sync_with_stdio(false);
    //struct timeval tv,end;
    //struct timezone tz;
    //gettimeofday(&tv, &tz);

    // Instantiation
    Dictionary_ Diction;

    // Read and process the command line.
    Diction.get_options(argc, argv);

    // Read in the data.
    Diction.read_();

    //
    Diction.run();


    Diction.output();
    //gettimeofday(&end, &tz);
    //std::cout<<1000*(end.tv_sec-tv.tv_sec) + (end.tv_usec-tv.tv_usec)/1000<<std::endl;
    return 0;

}


// Implementation//
void Dictionary_::get_options(int argc, char **argv) {
    int option_index = 0, option = 0;

    // Don't display getopt error messages about options ?
    opterr = false;

    struct option longOpts[] = {{ "stack"   , no_argument   , nullptr   , 's'},
                                { "queue"   , no_argument   , nullptr   , 'q'},
                                { "change"  , no_argument   , nullptr   , 'c'},
                                { "swap"    , no_argument   , nullptr   , 'p'},
                                { "length"  , no_argument   , nullptr   , 'l'},
                                { "output"  , required_argument, nullptr, 'o'},
                                { "begin"   , required_argument, nullptr, 'b'},
                                { "end"     , required_argument, nullptr, 'e'},
                                { "help"    , no_argument   , nullptr   , 'h'},
                                { nullptr   , 0              , nullptr   , '\0'}
    };

    while((option = getopt_long(argc, argv, "sqcplo:b:e:h", longOpts, &option_index)) != -1){
        switch (option){
            case 's':
                is_stack = true;
                break;
            case 'q':
                is_queue = true;
                break;
            case 'c':
                c = true;
                break;
            case 'p':
                p = true;
                break;
            case 'l':
                l = true;
                break;
            case 'o':
                if(optarg[0] == 'W'){
                    is_word = true;
                }
                else if(optarg[0] == 'M'){
                    is_word = false;
                    // the default is true.
                }
                else{
                    exit(1); // error: wrong argument.
                }
                break;
            case 'b':
                begin_w = optarg;
                //curr_w = optarg;
                break;
            case 'e':
                end_w = optarg;
                break;
            case 'h':
                // output any things.
                exit(0);
        }
    } // end while.
    if(is_stack == is_queue){
        exit(1); // error: no mode or two modes.
    }
    if(!(c|p|l)){
        exit(1); // error: no function
    }
    if(!l && (c || p) && begin_w.length() != end_w.length()){
        exit(1); // error: 5.
    }
}

void Dictionary_::read_() {

    Word temp;
    std::string tempp;
    // Read in the mode of dictionary.
    char simple;
    std::cin >> simple >> std::ws; // give it a try.
    std::cin >> total_num >> std::ws;

    if(simple == 'C'){
        is_simple = false;
        // Reserve the space. Deserve to be reconsidered.
        if(l){
            Dict.reserve((unsigned int)(total_num)*2);
        }
    }
    else{
        // Reserve the space.
        if(l){
            Dict.reserve((unsigned int)(total_num));
        }
        else{
            if(total_num < 350000){
                Dict.reserve((unsigned int)((float)total_num*0.7));
            }
            else{
                Dict.reserve((unsigned int)((float)total_num*0.6));
            }
        }
    }

    int cnt = 0;
    int cnt_line = 0;
    while(cnt_line < total_num){
        std::getline(std::cin, tempp);
        if(tempp.empty()){break;}
        // Ignore comments.
        if(tempp[0] != '/'){
            if(simple == 'C'){ // Complex.
                std::string::size_type pos_and = tempp.find('&');
                std::string::size_type pos_bracleft = tempp.find('[');
                std::string::size_type pos_bracright = tempp.find(']');
                std::string::size_type pos_exc = tempp.find('!');
                std::string::size_type pos_ques = tempp.find('?');
                if(pos_and != std::string::npos){
                    if(!l){
                        if(tempp.length() != begin_w.length() + 1){
                            ++cnt_line;
                            continue;
                        }
                    }
                    temp.content = tempp.substr(0, tempp.length()-1);
                    temp.index = cnt;
                    Dict.push_back(temp);
                    ++cnt;
                    std::reverse(temp.content.begin(), temp.content.end());
                    temp.index = cnt;
                    Dict.push_back(temp);
                }
                else if(pos_exc != std::string::npos){
                    if(!l){
                        if(tempp.length() != begin_w.length() + 1){
                            ++cnt_line;
                            continue;
                        }
                    }
                    temp.content = tempp.substr(0, pos_exc) + tempp.substr(pos_exc+1, tempp.length() - pos_exc - 1);
                    temp.index = cnt;
                    Dict.push_back(temp);
                    ++cnt;
                    char tem = temp.content[pos_exc-1];
                    temp.content[pos_exc-1] = temp.content[pos_exc-2];
                    temp.content[pos_exc-2] = tem;
                    temp.index = cnt;
                    Dict.push_back(temp);
                }
                else if(pos_ques != std::string::npos){
                    if(!l){
                        if(tempp.length() != begin_w.length() + 1 && tempp.length() != begin_w.length()){
                            ++cnt_line;
                            continue;
                        }
                    }
                    temp.content = tempp.substr(0, pos_ques) + tempp.substr(pos_ques+1, tempp.length() - pos_ques - 1);
                    temp.index = cnt;
                    Dict.push_back(temp);
                    ++cnt;
                    tempp[pos_ques] = tempp[pos_ques - 1];
                    temp.content = tempp;
                    temp.index = cnt;
                    Dict.push_back(temp);
                }
                else if(pos_bracleft != std::string::npos){
                    if(!l){
                        if(tempp.length() - (int)pos_bracright + (int)pos_bracleft != begin_w.length()){
                            ++cnt_line;
                            continue;
                        }
                    }
                    for(int i = 1; i < (int)pos_bracright - (int)pos_bracleft; ++i){
                        temp.content = tempp.substr(0, pos_bracleft) + tempp[pos_bracleft+i] + tempp.substr(pos_bracright+1, tempp.length() - pos_bracright - 1);
                        temp.index = cnt;
                        Dict.push_back(temp);
                        ++cnt;
                    }
                    --cnt; // cancel the last increment.
                }
                else{
                    temp.content = tempp;
                    temp.index = cnt;
                    Dict.push_back(temp);
                }
            } // end "C" if.
            else{ // simple dictionary.
                if(!l){
                    if(tempp.length() != begin_w.length()){
                        ++cnt_line;
                        continue;
                    }
                    temp.content = tempp;
                    temp.index = cnt;
                    Dict.push_back(temp);
                }
                else{
                    temp.content = tempp;
                    temp.index = cnt;
                    Dict.push_back(temp);
                }
            }
        }
        else{
            --cnt_line; // cancel the null counting.
            --cnt;
        }
        ++cnt;
        ++cnt_line;
    }
    bool flag_start_exist = false;
    bool flag_end_exist = false;
    for(const auto &i: Dict){
        if(i.content == begin_w){
            flag_start_exist = true;
        }
        if(i.content == end_w){
            flag_end_exist = true;
        }
    }
    if(!(flag_end_exist & flag_start_exist)){
        exit(1); // error: at least one cannot be found
    }
}

bool Dictionary_::judge(Word &dest) {
    //++nt;
    while(c){ // if can change
        if(curr_w.content.length() != dest.content.length()){
            break;
        }

        int num_of_different = 0;
        for(int i = 0; i < (int)curr_w.content.length(); ++i){
            if(curr_w.content[i] != dest.content[i]){
                ++num_of_different;
            }
        }
        if(num_of_different > 1){break;}
        return true;
    }
    while(p){ // if can swap
        if(curr_w.content.length() != dest.content.length()){
            break;
        }
        int num_of_different = 0;
        int pos_of_last = -1;
        for(int i = 0; i < (int)curr_w.content.length(); ++i){
            if(curr_w.content[i] != dest.content[i]){
                ++num_of_different;
                pos_of_last = i;
            }
        }
        if(num_of_different == 2 && curr_w.content[pos_of_last-1] == dest.content[pos_of_last] && curr_w.content[pos_of_last] == dest.content[pos_of_last-1]){
            return true;
        }
        break;
    }
    while(l){
        if(curr_w.content.length() != dest.content.length()-1 && curr_w.content.length() != dest.content.length()+1){
            break;
        }
        int help = 0;
        if(curr_w.content.length() > dest.content.length()){
            for(int i = 0; i < (int)dest.content.length(); ++i){
                if(curr_w.content[i+help] != dest.content[i]){
                    if(help == 1){ // Deserve to be reconsidered.
                        ++help;
                        break;
                    }
                    help = 1;
                    --i;
                }
            }
            if(help == 2){break;}
            else{return true;}
        }
        else{
            for(int i = 0; i < (int)dest.content.length(); ++i){
                if(curr_w.content[i+help] != dest.content[i]){
                    if(help == -1){ // Deserve to be reconsidered.
                        --help;
                        break;
                    }
                    help = -1;
                }
            }
            if(help == -2){break;}
            else{return true;}
        }
    }
    return false;
}

bool Dictionary_::judge_nol(Word &dest) {
    int num_of_different = 0;
    int pos_of_last = -1;
    for(int i = 0; i < (int)curr_w.content.length(); ++i){
        if(curr_w.content[i] != dest.content[i]){
            ++num_of_different;
            pos_of_last = i;
        }
    }
    if(num_of_different == 1 && c){
        return true;
    }
    if(num_of_different ==2 && p && curr_w.content[pos_of_last-1] == dest.content[pos_of_last] && curr_w.content[pos_of_last] == dest.content[pos_of_last-1]){
        return true;
    }
    return false;
}

void Dictionary_::run() {

    // initialization.
    for(auto& i:Dict){ // Deserve to be reconsidered.
        if(i.content == begin_w){
            container.push_back(i.index);
            i.status = true;
        }
    }

    while(!container.empty()){
        if(is_stack){ // using DFS.
            curr_w = Dict[container.back()];
            container.pop_back();
        }
        else{ // using BFS.
            curr_w = Dict[container.front()];
            container.pop_front();
        }
        if(curr_w.content == end_w){
            can_reach = true;
        }
        for(auto& i:Dict){
            if((!l && !i.status && judge_nol(i)) || (l && !i.status && judge(i))){
                i.status = true;
                i.prev = curr_w.index;
                container.push_back(i.index);
                if(i.content == end_w){
                    can_reach = true;
                }
            }
            //++total_searches;
        }
        if(can_reach){
            break;
        }
    }
}

void Dictionary_::output() {
    int total_searches = 0;
    for(const auto& i:Dict){
        if(i.status){
            ++total_searches;
        }
    }
    if(!can_reach){
        std::cout<<"No solution, "<<total_searches<<" words discovered.\n";
        return;
    }
    int end_index = -1;
    for(const auto& i:Dict){
        if(i.content == end_w){
            end_index = i.index;
        }
    }
    int temp_index = end_index;
    while(Dict[temp_index].content != begin_w){
        temp_index = Dict[temp_index].prev;
        ++total_changes;
    }
    if(is_word){
        std::cout<<"Words in morph: "<<total_changes<<"\n";
        simple_output(end_index);
        return ;
    }
    else{ // Modification.
        std::cout<<"Words in morph: "<<total_changes<<"\n";
        std::cout<<begin_w<<'\n';
        if(total_changes == 1){
            return;
        }
        modi_output(end_index);
        return;
    }
}

void Dictionary_::simple_output(int temp) {
    if(Dict[temp].content == begin_w){
        std::cout<<Dict[temp].content<<"\n";
        return;
    }
    simple_output(Dict[temp].prev);
    std::cout<<Dict[temp].content<<"\n";
}

void Dictionary_::modi_output(int temp) {
    if(Dict[Dict[temp].prev].content == begin_w){
        modi_judge(Dict[Dict[temp].prev].content, Dict[temp].content);
        return;
    }
    modi_output(Dict[temp].prev);
    modi_judge(Dict[Dict[temp].prev].content, Dict[temp].content);
}

void Dictionary_::modi_judge(std::string &origin, std::string &target){
    // First for change and swap.
    if(origin.length() == target.length()){
        int num_of_different = 0;
        int different_index = -1;
        for(int i = 0; i < (int)origin.length(); ++i){
            if(origin[i] != target[i]){
                ++num_of_different;
                different_index = i;
            }
        }

        if(num_of_different == 1){ // for change.
            std::cout<<"c,"<<different_index<<','<<target[different_index]<<'\n';
            return;
        }
        else{ // There are only two situations.
            std::cout<<"s,"<<different_index-1<<'\n';
            return;
        }
    }
    else{ // for delete or insert.
        if(origin.length() > target.length()){ // deletion.
            int different_index = -1;
            for(int i = 0; i < (int)target.length(); ++i){
                if(origin[i] != target[i]){
                    different_index = i;
                    break;
                }
            }
            if(different_index == -1){ // the last char is different.
                different_index = (int)target.length();
            }
            std::cout<<"d,"<<different_index<<'\n';
            return;
        }
        else{ // insertion
            int different_index = -1;
            for(int i = 0; i < (int)origin.length(); ++i){
                if(origin[i] != target[i]){
                    different_index = i;
                    break;
                }
            }
            if(different_index == -1){ // the last char is different.
                different_index = (int)origin.length();
            }
            std::cout<<"i,"<<different_index<<','<<target[different_index]<<'\n';
            return;
        }
    }
}

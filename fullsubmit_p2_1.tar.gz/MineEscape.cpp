// Project Identifier: 19034C8F3B1196BF8E0C6E1C0F973D2FD550B88F
// Created by 26673 on 2020/9/14.
//
#include <deque>
#include <queue>
#include <vector>
#include <iostream>
#include <algorithm> // std::sort
#include <getopt.h>
#include <string>    // needed for VS
#include<stdio.h>
#include<sys/time.h>
#include<unistd.h>
#include <iomanip>
#include "P2random.h"
#include <stdlib.h>

typedef struct {
    unsigned int c_ = 0;
    unsigned int r_ = 0;
    int rubble = 0;
    //bool discovered = false; // true for discovered.
} Pile;

struct sort_by_rubble{

    bool operator()(Pile &a, Pile &b){
        if(a.rubble != b.rubble){
            return a.rubble > b.rubble;
        }
        else{
            if(a.c_ != b.c_){
                return a.c_ > b.c_;
            }
            else{
                return a.r_ > b.r_;
            }
        }
    }
};

struct sort_by_rubble_reverse{

    bool operator()(Pile &a, Pile &b){
        if(a.rubble != b.rubble){
            return a.rubble < b.rubble;
        }
        else{
            if(a.c_ != b.c_){
                return a.c_ < b.c_;
            }
            else{
                return a.r_ < b.r_;
            }
        }
    }
};

class MedianFinder {
public:
    /** initialize your data structure here. */
    MedianFinder() = default;

    void addNum(int num) {
        // 讲新加入的数字放到size 小的栈里面, 如果都为空， 放到SmallHalf stack中
        if (BigHalf.size() >= SmallHalf.size()) {
            SmallHalf.push(num);
        } else
            BigHalf.push(num);
        // 第一个元素被放在了SmallHalf里面
        if (BigHalf.empty())
            return;

        // 如果BigHalf的最小值小于了SmallHalf的最大值，则需要调整，这里交换堆顶元素即可
        if (BigHalf.top() < SmallHalf.top()) {
            BigHalf.push(SmallHalf.top());
            SmallHalf.push(BigHalf.top());
            BigHalf.pop();
            SmallHalf.pop();
        }
    }

    double findMedian() {
        int n1 = (int)BigHalf.size();
        int n2 = (int)SmallHalf.size();
        if ((n1 + n2) % 2 == 0) {
            return (BigHalf.top() + SmallHalf.top()) * 1.0 / 2;
        }

        return n1 > n2? BigHalf.top() : SmallHalf.top();
    }
private:
    // top small
    std::priority_queue<int, std::vector<int>, std::greater<int> > BigHalf;
    // top big
    std::priority_queue<int, std::vector<int>, std::less<int> > SmallHalf;
};

class Miner_{

public:

    Miner_() = default;

    // read file.
    void read_();

    //Read and process command line arguments.
    void get_options(int argc, char** argv);

    void run();

    void output();

private:

    // The whole mine.
    std::vector<std::vector< int> > Miner;

    // PQ used.
    std::priority_queue<Pile, std::vector<Pile>, sort_by_rubble> PQ;

    // PQ used in explosion.
    std::priority_queue<Pile, std::vector<Pile>, sort_by_rubble> pq_ex;


    // clear the current temp r and c pile and process the information.
    void clear();

    // push surrounding into PQ if not discovered.
    void add();

    // Explosion ~~~
    void one_explosion(unsigned int r,  unsigned int c);

    bool is_M = false;
    bool is_R = false;
    bool is_stats = false;
    unsigned int N = 0; // for stats.
    bool is_median = false;
    bool is_verbose = false;
    // For M.
    unsigned int floor_size = 0;
    unsigned int r_start = 0;
    unsigned int c_start = 0;
    // For Random.
    unsigned int seed = 0;
    unsigned int max_rubble = 0;
    unsigned int tnt_chance = 0;

    //unsigned int temp_r = 0;
    //unsigned int temp_c = 0;
    int max_cost = 0;

    // Used for Stats.
    std::vector<Pile> clear_seq;
    Pile temp;

    // Used for Median.
    MedianFinder Median;

    // Used for Default.
    unsigned int sum = 0;
    unsigned int num = 0;
};


// Implementation //
void Miner_::get_options(int argc, char **argv) {
    int option_index = 0, option = 0;

    // Don't display getopt error messages about options ?
    opterr = false;

    struct option longOpts[] = {{ "stats"   , required_argument   , nullptr   , 's'},
                                { "median"   , no_argument   , nullptr   , 'm'},
                                { "verbose"  , no_argument   , nullptr   , 'v'},
                                { "help"    , no_argument   , nullptr   , 'h'},
                                { nullptr   , 0              , nullptr   , '\0'}
    };

    while((option = getopt_long(argc, argv, "s:mvh", longOpts, &option_index)) != -1){
        switch (option){
            case 's':
                is_stats = true;
                N = atoi(optarg);
                break;
            case 'm':
                is_median = true;
                break;
            case 'v':
                is_verbose = true;
                break;
            case 'h':
                // output any things.
                std::cout<<"a description of your executable and "<<std::endl;
                exit(0);
        }
    } // end while.

}

// Read //
void Miner_::read_() {
    char mode;
    std::cin>>mode;
    std::string line;
    std::string waste;
    std::getline(std::cin,line);

    std::stringstream ss;
    if(mode != 'R' && mode != 'M'){
        std::cerr<<"Invalid input mode\n";
        exit(1); // Error: wrong mode.
    }
    std::stringstream buffer;
    if(mode == 'R'){
        // read size
        std::getline(std::cin, line);
        buffer.str(""); // clear the buffer.
        buffer.clear();
        buffer<<line;
        buffer>>waste;
        buffer>>floor_size;

        // read start
        std::getline(std::cin, line);
        buffer.str(""); // clear the buffer.
        buffer.clear();
        buffer<<line;
        buffer>>waste;
        buffer>>r_start;
        buffer>>c_start;

        // read seed
        std::getline(std::cin, line);
        buffer.str(""); // clear the buffer.
        buffer.clear();
        buffer<<line;
        buffer>>waste;
        buffer>>seed;

        // read max rubble
        std::getline(std::cin, line);
        buffer.str(""); // clear the buffer.
        buffer.clear();
        buffer<<line;
        buffer>>waste;
        buffer>>max_rubble;

        // read tnt ratio
        std::getline(std::cin, line);
        buffer.str(""); // clear the buffer.
        buffer.clear();
        buffer<<line;
        buffer>>waste;
        buffer>>tnt_chance;

        P2random::PR_init(ss, floor_size, seed, max_rubble, tnt_chance);
    }
    else{
        // read size
        std::getline(std::cin, line);
        buffer.str(""); // clear the buffer.
        buffer.clear();
        buffer<<line;
        buffer>>waste;
        buffer>>floor_size;

        // read start
        std::getline(std::cin, line);
        buffer.str(""); // clear the buffer.
        buffer.clear();
        buffer<<line;
        buffer>>waste;
        buffer>>r_start;
        buffer>>c_start;
    }
    // for M.

    std::istream &inputStream = (mode == 'M') ? std::cin : ss;

    if(r_start >= floor_size || c_start >= floor_size){ // They are unsigned int.
        std::cerr<<"Invalid starting place\n";
        exit(1); // Error: start address is outside the reasonable part.
    }

    // Read in the Miner.
    std::vector<int> temp(floor_size,0);
    for(unsigned int row = 0; row < floor_size; ++row){
        std::getline(inputStream, line);
        buffer.str("");
        buffer.clear();
        buffer<<line;
        for(unsigned int col = 0; col < floor_size; ++col){
            buffer>>temp[col];
            max_cost = (max_cost > temp[col]) ? max_cost : temp[col]; // maintain max_cost be the most expensive.
        }
        Miner.push_back(temp);
    }

}

// Run //
void Miner_::run() {
    // Start //
    //temp_c = c_start;
    //temp_r = r_start;
    temp.r_ = r_start;
    temp.c_ = c_start;
    temp.rubble = Miner[r_start][c_start];

    while(true){
        //std::cout<<temp.r_<<"  "<<temp.c_<<std::endl;

        clear();

        if(temp.c_ == 0 || temp.r_ == 0 || temp.c_ == floor_size-1 || temp.r_ == floor_size-1){
            break;
        }

        temp = PQ.top();
        PQ.pop();

    }

}


void Miner_::clear() {
    Pile temp_ex;
    //temp.r_ = temp_r;
    //temp.c_ = temp_c;
    if(temp.rubble == 0){ // Handle 0 case.
        add();
        Miner[temp.r_][temp.c_] = max_cost+1; // Meaning discovered. !!!Important!!!
    }
    else if(Miner[temp.r_][temp.c_] == max_cost+1){ // Omit case !!!
    }
    else if(temp.rubble != -1 ){ // Normal pile.
        // Handle the output //
        if(is_stats){
            clear_seq.push_back(temp);
        }
        if(is_verbose){
            std::cout<<"Cleared: "<<temp.rubble<<" at ["<<temp.r_<<','<<temp.c_<<"]\n";
        }
        if(is_median){ // note //
            Median.addNum(temp.rubble);
            std::cout<<"Median difficulty of clearing rubble is: "<<Median.findMedian()<<'\n';
        }
        ++num;
        sum += temp.rubble;
        add();
        Miner[temp.r_][temp.c_] = max_cost+1; // Meaning discovered. !!!Important!!!
    }
    else{ // It is a TNT!!!!!!! Important !!!!!!!
        // Handle output //
        if(is_stats){
            clear_seq.push_back(temp);
        }
        if(is_verbose){
            std::cout<<"TNT explosion at ["<<temp.r_<<','<<temp.c_<<"]!\n";
        }

        Miner[temp.r_][temp.c_] = max_cost+1; // Mark as discovered

        // Handle the explosion effect // !!!
        one_explosion(temp.r_, temp.c_);
        while(!pq_ex.empty()){ // Handle the pq in explosion process.
            temp_ex = pq_ex.top();
            pq_ex.pop();
            if(temp_ex.rubble == 0){
                PQ.push(temp_ex);
                Miner[temp_ex.r_][temp_ex.c_] = max_cost+1; // Mark as discovered.
            }
            else if(temp_ex.rubble != -1){ // if only normal remains.
                if(is_stats){
                    clear_seq.push_back(temp_ex);
                }
                if(is_verbose){
                    std::cout<<"Cleared by TNT: "<<temp_ex.rubble<<" at ["<<temp_ex.r_<<','<<temp_ex.c_<<"]\n";
                }
                if(is_median){ // note //
                    Median.addNum(temp_ex.rubble);
                    std::cout<<"Median difficulty of clearing rubble is: "<<Median.findMedian()<<'\n';
                }
                ++num;
                sum += temp_ex.rubble;
                temp_ex.rubble = 0; // Being cleared.
                PQ.push(temp_ex);
                Miner[temp_ex.r_][temp_ex.c_] = max_cost+1; // Mark as discovered.
            }
            else{ // it is a TNT
                if(is_stats){
                    clear_seq.push_back(temp_ex);
                }
                if(is_verbose){
                    std::cout<<"TNT explosion at ["<<temp_ex.r_<<','<<temp_ex.c_<<"]!\n";
                }
                PQ.push(temp_ex);
                one_explosion(temp_ex.r_, temp_ex.c_); //
                Miner[temp_ex.r_][temp_ex.c_] = max_cost+1; // Mark as discovered.
            }
        }

    }
}


void Miner_::add(){
    Pile tempp;
    tempp = temp;
    if(tempp.r_ > 0){
        --tempp.r_;
        tempp.rubble = Miner[tempp.r_][tempp.c_];
        if(tempp.rubble != max_cost+1){ // If been discovered, cost will be max+1.
            PQ.push(tempp);
        }
        ++tempp.r_;
    }
    if(tempp.c_ > 0){
        --tempp.c_;
        tempp.rubble = Miner[tempp.r_][tempp.c_];
        if(tempp.rubble != max_cost+1){ // If been discovered, cost will be max+1.
            PQ.push(tempp);
        }
        ++tempp.c_;
    }
    if(tempp.r_ < floor_size-1){
        ++tempp.r_;
        tempp.rubble = Miner[tempp.r_][tempp.c_];
        if(tempp.rubble != max_cost+1){ // If been discovered, cost will be max+1.
            PQ.push(tempp);
        }
        --tempp.r_;
    }
    if(tempp.c_ < floor_size-1){
        ++tempp.c_;
        tempp.rubble = Miner[tempp.r_][tempp.c_];
        if(tempp.rubble != max_cost+1){ // If been discovered, cost will be max+1.
            PQ.push(tempp);
        }
        --tempp.c_;
    }
}


void Miner_::one_explosion(unsigned int r,  unsigned int c) {
    Pile tempp;
    tempp.r_ = r;
    tempp.c_ = c;
    if(tempp.r_ > 0){
        --tempp.r_;
        tempp.rubble = Miner[tempp.r_][tempp.c_];
        if(tempp.rubble != max_cost+1){ // If been discovered, cost will be max+1.
            pq_ex.push(tempp); // push into explosion temp pq.
            Miner[tempp.r_][tempp.c_] = max_cost+1; // Mark as discovered; note.
        }
        ++tempp.r_;
    }
    if(tempp.c_ > 0){
        --tempp.c_;
        tempp.rubble = Miner[tempp.r_][tempp.c_];
        if(tempp.rubble != max_cost+1){ // If been discovered, cost will be max+1.
            pq_ex.push(tempp); // push into explosion temp pq.
            Miner[tempp.r_][tempp.c_] = max_cost+1; // Mark as discovered; note.
        }
        ++tempp.c_;
    }
    if(tempp.r_ < floor_size-1){
        ++tempp.r_;
        tempp.rubble = Miner[tempp.r_][tempp.c_];
        if(tempp.rubble != max_cost+1){ // If been discovered, cost will be max+1.
            pq_ex.push(tempp); // push into explosion temp pq.
            Miner[tempp.r_][tempp.c_] = max_cost+1; // Mark as discovered; note.
        }
        --tempp.r_;
    }
    if(tempp.c_ < floor_size-1){
        ++tempp.c_;
        tempp.rubble = Miner[tempp.r_][tempp.c_];
        if(tempp.rubble != max_cost+1){ // If been discovered, cost will be max+1.
            pq_ex.push(tempp); // push into explosion temp pq.
            Miner[tempp.r_][tempp.c_] = max_cost+1; // Mark as discovered; note.
        }
        --tempp.c_;
    }
}


void Miner_::output() {
    // Default
    std::cout<<"Cleared "<<num<<" tiles containing "<<sum<<" rubble and escaped.\n";
    if(is_stats){
        if(N > clear_seq.size()){
            N = (int)clear_seq.size();
        }
        // First tiles.
        std::cout<<"First tiles cleared:\n";
        for(unsigned int i = 0; i < N; ++i){
            if(clear_seq[i].rubble == -1){
                std::cout<<"TNT at ["<<clear_seq[i].r_<<','<<clear_seq[i].c_<<"]\n";
            }
            else{
                std::cout<<clear_seq[i].rubble<<" at ["<<clear_seq[i].r_<<','<<clear_seq[i].c_<<"]\n";
            }
        }
        // Last
        std::reverse(clear_seq.begin(), clear_seq.end());
        std::cout<<"Last tiles cleared:\n";
        for(unsigned int i = 0; i < N; ++i){
            if(clear_seq[i].rubble == -1){
                std::cout<<"TNT at ["<<clear_seq[i].r_<<','<<clear_seq[i].c_<<"]\n";
            }
            else{
                std::cout<<clear_seq[i].rubble<<" at ["<<clear_seq[i].r_<<','<<clear_seq[i].c_<<"]\n";
            }
        }

        std::sort(clear_seq.begin(), clear_seq.end(), sort_by_rubble());
        std::reverse(clear_seq.begin(), clear_seq.end());
        std::cout<<"Easiest tiles cleared:\n";
        for(unsigned int i = 0; i < N; ++i){
            if(clear_seq[i].rubble == -1){
                std::cout<<"TNT at ["<<clear_seq[i].r_<<','<<clear_seq[i].c_<<"]\n";
            }
            else{
                std::cout<<clear_seq[i].rubble<<" at ["<<clear_seq[i].r_<<','<<clear_seq[i].c_<<"]\n";
            }
        }

        std::reverse(clear_seq.begin(), clear_seq.end());
        std::cout<<"Hardest tiles cleared:\n";
        for(unsigned int i = 0; i < N; ++i){
            if(clear_seq[i].rubble == -1){
                std::cout<<"TNT at ["<<clear_seq[i].r_<<','<<clear_seq[i].c_<<"]\n";
            }
            else{
                std::cout<<clear_seq[i].rubble<<" at ["<<clear_seq[i].r_<<','<<clear_seq[i].c_<<"]\n";
            }
        }
    }
}


int main(int argc, char **argv) {
    std::ios_base::sync_with_stdio(false);
    std::cout<< std::fixed<< std::setprecision(2);
    /*std::priority_queue<Pile, std::vector<Pile>, sort_by_rubble> PQ;
    for(int i = 0; i < 4; ++i){
        Pile j;
        j.r_ = i;
        j.c_ = i;
        j.rubble = i;
        PQ.push(j);
    }
    for(int i = 0; i < 4; ++i){
        std::cout<<PQ.top().rubble<<std::endl;
        PQ.pop();
    }*/
    Miner_ M;
    M.get_options(argc, argv);
    M.read_();
    M.run();
    M.output();
    //std::cout << "Hello, World!" << std::endl;
    return 0;
}

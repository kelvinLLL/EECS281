// Project Identifier: C0F4DFE8B340D81183C208F70F9D2D797908754D
#include <iostream>
#include "TableEntry.h"
#include <getopt.h>
#include <unordered_map>
#include <map>
#include <vector>
#include <cstring>
#include <iterator>
#include <algorithm> // std::sort
using namespace std;

class table_already_exist{
public:
    explicit table_already_exist(string &Name): name(Name){}

    string name;
};
class table_no_exist{
public:
    explicit table_no_exist(string &Name): name(Name){}

    string name;
};
class col_no_exist{
public:
    explicit col_no_exist(string &Name, string &Col): name(Name), col(Col){}

    string name;
    string col;
};
class wrong_command{};

struct In{
    EntryType ent;
    int ind;
};
class Table_{

public:

    Table_() = default;

    string name;


    // ALL DATA PART
    std::vector<std::vector<TableEntry> > data;

    //vector<string> column_name;

    // Infomation of table column
    //std::unordered_map<string, In> info;

    vector<EntryType > col_typ;

    vector<string> col_info;

    // Functions...
    int Delete(const TableEntry& tbe,char oper, int ind);

    void generate_index(int col_index);

    void print(bool is_q);
    void print_help(bool is_q, const TableEntry& tbe, char oper, vector<int>& col_ind, int obj_col);

    int join(vector<TableEntry> &obj, vector<int> &col_ind, vector<int> &col_belong, bool is_q, int obj_col_self, int obj_col_others);
    void join_help(int obj_col);

    std::unordered_map<TableEntry, vector<int> > hash_;
    std::map<TableEntry, vector<int> > bst_;

    char index_type = ' '; // empty for no index, h for hash, b for binary search tree.
    int ind_coluumn = -1;

    unordered_map<TableEntry, vector<int> > tem_for_join;

private:

};

class Eq{
public:
    explicit Eq(const TableEntry& Target, int Index): target(std::move(Target)), index(Index){}

    bool operator() (const vector<TableEntry>& sub){

        return sub[index] == target;
    }

    TableEntry target;
    int index;

};
class Lt{
public:
    explicit Lt(const TableEntry& Target, int Index): target(std::move(Target)), index(Index){}

    bool operator() (const vector<TableEntry>& sub){
        return sub[index] < target;
    }
private:
    TableEntry target;
    int index;
};
class Gt{
public:
    explicit Gt(const TableEntry& Target, int Index): target(std::move(Target)), index(Index){}

    bool operator() (const vector<TableEntry>& sub){
        return sub[index] > target;
    }
private:
    TableEntry target;
    int index;
};

class SillyQL_{

public:

    SillyQL_() = default;

    // Read and process command line arguments.
    void get_options(int argc, char** argv);

    void run();

    bool flag_ending = false;

private:

    //unordered_map<string, int> table_map;
    unordered_map<string, Table_> table_Map;
    //vector<Table_> table_vec;

    bool is_quiet = false;

};

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    std::cin>>std::boolalpha;
    std::cout<<std::boolalpha;
    SillyQL_ Go;
    Go.get_options(argc, argv);
    while(!Go.flag_ending){
        try{
            Go.run();
        }
        catch(table_already_exist& e){
            cout<<"Error: Cannot create already existing table "<< e.name<<'\n';
        }
        catch(table_no_exist& e){
            cout<<"Error: "<<e.name<<" does not name a table in the database\n";
        }
        catch (col_no_exist& e){
            cout<<"Error: "<<e.col<<" does not name a column in "<<e.name<<'\n';
        }
        catch(wrong_command& e){
            cout<<"Error: unrecognized command\n";
        }
    }

    return 0;
}

void SillyQL_::get_options(int argc, char **argv) {
    for(int i = 1; i < argc; i++) {
        if(strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) exit(0);
        else if(strcmp(argv[i], "-q") == 0 || strcmp(argv[i], "--quiet") == 0) is_quiet = true;
    }/*
    int option_index = 0, option = 0;
    // Don't display getopt error messages about options ?
    opterr = false;

    struct option longOpts[] = {{ "help"   , no_argument   , nullptr   , 'h'},
                                { "quiet"   , no_argument   , nullptr   , 'q'},
                                { nullptr   , 0              , nullptr   , '\0'}
    };

    while((option = getopt_long(argc, argv, "hq", longOpts, &option_index)) != -1){
        switch (option){
            case 'q':
                is_quiet = true;
                break;
            case 'h':
                // output any things.
                exit(0);
            default:
                ;
        }
    } // end while.
    */
}

void SillyQL_::run() {
    std::string command;
    std::string trash;
    std::string tablename;
    int num;
    std::string coltype;
    std::string colname;
    string data0;
    char oper;
    double data1;
    int data2;
    bool data3;
    string tabletype; // hash or bst

    do{
        std::cout<<"% ";
        std::cin>>command;
        switch (command[0]){
            case 'Q':
                std::cout<<"Thanks for being silly!\n";
                flag_ending = true;
                break;
            case '#':
                std::getline(std::cin, trash); // Handle comments
                break;
            case 'C': // Create
            {
                cin >> tablename >> num;
                if(table_Map.find(tablename)!=table_Map.end()){
                    // ERROR!
                    getline(cin, trash);
                    throw table_already_exist(tablename);
                }

                vector<EntryType > temp_coltype;
                Table_ temp_table;
                temp_table.name = tablename;
                temp_table.col_typ.reserve((unsigned long long)num+1);
                temp_table.col_info.reserve((unsigned long long)num+1);
                //temp_coltype.reserve((unsigned long long) num+1);
                //temp_table.info.reserve((unsigned long long) num+1);
                //temp_table.column_name.reserve((unsigned long long) num);
                for (int i = 0; i < num; ++i) {
                    cin >> coltype;
                    switch (coltype[0]) {
                        case 's':
                            temp_table.col_typ.emplace_back(EntryType::String);
                            //temp_coltype.push_back(EntryType::String);
                            break;
                        case 'd':
                            temp_table.col_typ.emplace_back(EntryType::Double);
                            //temp_coltype.push_back(EntryType::Double);
                            break;
                        case 'i':
                            //temp_coltype.push_back(EntryType::Int);
                            temp_table.col_typ.emplace_back(EntryType::Int);
                            break;
                        case 'b':
                            //temp_coltype.push_back(EntryType::Bool);
                            temp_table.col_typ.emplace_back(EntryType::Bool);
                            break;
                        default:;
                    }
                }
                cout<<"New table "<<tablename<<" with column(s) ";
                //vector<string> p_col_temp;
                for (int i = 0; i < num; ++i) {
                    cin >> colname;
                    temp_table.col_info.emplace_back(colname);
                    cout<<colname<<' ';
                    //temp_table.column_name.emplace_back(colname);
                    //temp_table.info.emplace(colname, In{temp_coltype[i], i});
                }
                cout<<"created\n";
                table_Map.emplace(tablename, temp_table);
                //table_map.emplace(tablename, table_vec.size());
                //table_vec.emplace_back(temp_table);
                cin.get();
                break;
            }
            case 'I': {
                cin >> trash >> tablename >> num >> trash;
                cin.get();
                const auto& it = table_Map.find(tablename);
                if(it == table_Map.end()){
                    // ERROR!
                    for(int i = 0; i < num; ++i){
                        getline(cin, trash);
                    }
                    throw table_no_exist(tablename);
                }
                Table_& re_table = it->second;
                unsigned long long colnum = re_table.col_info.size();
                //unsigned long long colnum = re_table.info.size();
                cout<<"Added "<<num<<" rows to "<<tablename<<" from position "<<re_table.data.size()<<" to "<<re_table.data.size()+num-1<<'\n';
                const int& tt = (int)re_table.data.size();
                re_table.data.resize((re_table.data.size()+num)); // resize rows
                // Output
                for(int i = 0; i < num; ++i){
                    re_table.data[i+tt].reserve(colnum); // resize columns
                    for(unsigned long long j = 0; j < colnum; ++j){
                        const EntryType &typ = re_table.col_typ[j];
                        //const int &typ = (int)re_table.info[re_table.col_info[j]].ent;
                        switch (typ) {
                            case EntryType ::String: // string
                            {
                                cin >> data0;
                                //TableEntry t(data0);
                                re_table.data[i + tt].emplace_back(data0);
                                break;
                            }
                            case  EntryType ::Double: // double
                            {
                                cin >> data1;
                                //TableEntry t(data1);
                                re_table.data[i + tt].emplace_back(data1);
                                break;
                            }
                            case  EntryType ::Int: // int
                            {
                                cin >> data2;
                                //TableEntry t(data2);
                                re_table.data[i + tt].emplace_back(data2);
                                break;
                            }
                            case  EntryType ::Bool: // bool
                            {
                                cin >> data3;
                                //TableEntry t(data3);
                                re_table.data[i + tt].emplace_back(data3);
                                break;
                            }
                            default:;
                        }
                    }
                }
                if(re_table.index_type != ' '){
                    re_table.generate_index(re_table.ind_coluumn);
                }
                break;
            }
            case 'D':{
                cin>>trash>>tablename>>trash>>colname>>oper; // Value need to be read.
                const auto& it = table_Map.find(tablename);
                if(it == table_Map.end()){
                    // ERROR!
                    getline(cin,trash);
                    throw table_no_exist(tablename);
                }
                Table_& re_table = it->second;
                int ind = -1;
                for (int i = 0; i < (int)re_table.col_info.size(); ++i)
                    if (re_table.col_info[i] == colname) {
                        ind = i;
                        break;
                    }
                if (ind == -1) {
                    // ERROR!
                    getline(cin,trash);
                    throw col_no_exist(tablename, colname);
                }

                /*const auto& it2 = re_table.info.find(colname);
                if(it2 == re_table.info.end()){
                    // ERROR!
                    getline(cin,trash);
                    throw col_no_exist(tablename, colname);
                }*/
                //const int& typ = (int) it2->second.ent;
                //const int& ind = it2->second.ind;
                const EntryType& typ = re_table.col_typ[ind];
                switch (typ) {
                    case EntryType ::String: { // string
                        cin >> data0;
                        TableEntry tbe(data0);
                        num = re_table.Delete(tbe, oper, ind);
                        break;
                    }
                    case EntryType ::Double: // double
                    {
                        cin >> data1;
                        TableEntry tbe(data1);
                        num = re_table.Delete(tbe, oper, ind);
                        break;
                    }
                    case EntryType ::Int: // int
                    {
                        cin >> data2;
                        TableEntry tbe(data2);
                        num = re_table.Delete(tbe, oper, ind);
                        break;
                    }
                    case EntryType ::Bool: // bool
                    {
                        cin >> data3;
                        TableEntry tbe(data3);
                        num = re_table.Delete(tbe, oper, ind);
                        break;
                    }
                    default:;
                }
                cout<<"Deleted "<<num<<" rows from "<<tablename<<'\n';
                if(num != 0 && re_table.index_type != ' '){
                    re_table.generate_index(re_table.ind_coluumn);
                }
                break;
            }
            case 'G':
            {
                cin>>trash>>tablename>>tabletype>>trash>>trash>>colname;
                cin.get();
                const auto& it = table_Map.find(tablename);
                if(it == table_Map.end()){
                    // ERROR!
                    throw table_no_exist(tablename);
                }
                Table_& re_table = it->second;

                int ind = -1;
                for (int i = 0; i < (int)re_table.col_info.size(); ++i)
                    if (re_table.col_info[i] == colname) {
                        ind = i;
                        break;
                    }
                if (ind == -1) {
                    // ERROR!
                    throw col_no_exist(tablename, colname);
                }

                /*const auto& it2 = re_table.info.find(colname);
                if(it2 == re_table.info.end()){
                    // ERROR!
                    throw col_no_exist(tablename, colname);
                }*/
                //int typ = (int) it2->second.ent;
                //const int& ind = it2->second.ind;
                re_table.index_type = tabletype[0];
                re_table.ind_coluumn = ind;
                re_table.generate_index(ind);
                cout<<"Created "<<tabletype<<" index for table "<<tablename<<" on column "<<colname<<'\n';
                break;
            }
            case 'P':
            {
                cin>>trash>>tablename;
                const auto& it = table_Map.find(tablename);
                if(it == table_Map.end()){
                    // ERROR!
                    getline(cin, trash);
                    throw table_no_exist(tablename);
                }
                Table_& re_table = it->second;
                re_table.print(is_quiet);
                break;
            }
            case 'J':
            {
                string table1, table2, colname1, colname2, p_col;
                //int col2_index, col1_index; // 1 or 2
                cin>>table1>>trash>>table2>>trash>>colname1>>oper>>colname2>>trash>>trash;
                const auto& it1 = table_Map.find(table1);
                if(it1 == table_Map.end()){
                    // ERROR!
                    getline(cin,trash);
                    throw table_no_exist(table1);
                }
                const auto& it2 = table_Map.find(table2);
                if(it2 == table_Map.end()){
                    // ERROR!
                    getline(cin,trash);
                    throw table_no_exist(table2);
                }
                Table_& re_table1 = it1->second;
                Table_& re_table2 = it2->second;

                int col1_index = -1;
                for (int i = 0; i < (int)re_table1.col_info.size(); ++i)
                    if (re_table1.col_info[i] == colname1) {
                        col1_index = i;
                        break;
                    }
                if (col1_index == -1) {
                    // ERROR!
                    getline(cin,trash);
                    throw col_no_exist(table1, colname1);
                }
                int col2_index = -1;
                for (int i = 0; i < (int)re_table2.col_info.size(); ++i)
                    if (re_table2.col_info[i] == colname2) {
                        col2_index = i;
                        break;
                    }
                if (col2_index == -1) {
                    // ERROR!
                    getline(cin,trash);
                    throw col_no_exist(table2, colname2);
                }

                /*const auto& it1c = re_table1.info.find(colname1);
                if(it1c == re_table1.info.end()){
                    // ERROR!
                    getline(cin,trash);
                    throw col_no_exist(table1, colname1);
                }*/
                /*const auto& it2c = re_table2.info.find(colname2);
                if(it2c == re_table2.info.end()){
                    // ERROR!
                    getline(cin,trash);
                    throw col_no_exist(table2, colname2);
                }*/
                //col1_index = it1c->second.ind;
                //col2_index = it2c->second.ind;
                int belong;
                string p_colname;
                cin >> num;
                vector<int> col_ind;
                vector<int> col_belong;
                vector<string> p_col_temp;
                for(int i = 0; i < num; ++i){
                    cin>>p_colname>>belong;
                    //auto it = re_table1.info.begin();
                    col_belong.emplace_back(belong);
                    int index = -1;
                    if(belong == 1){ // for 1
                        for (int j = 0; j < (int)re_table1.col_info.size(); ++j)
                            if (re_table1.col_info[j] == p_colname) {
                                index = j;
                                break;
                            }
                        if (index == -1) {
                            // ERROR!
                            getline(cin,trash);
                            throw col_no_exist(table1, p_colname);
                        }
                        /*it = re_table1.info.find(p_colname);
                        if(it == re_table1.info.end()){
                            // ERROR
                            getline(cin,trash);
                            throw col_no_exist(table1, p_colname);
                        }*/
                    }
                    else{ // for 2
                        for (int j = 0; j < (int)re_table2.col_info.size(); ++j)
                            if (re_table2.col_info[j] == p_colname) {
                                index = j;
                                break;
                            }
                        if (index == -1) {
                            // ERROR!
                            getline(cin,trash);
                            throw col_no_exist(table2, p_colname);
                        }
                        /*it = re_table2.info.find(p_colname);
                        if(it == re_table2.info.end()){
                            // ERROR
                            getline(cin,trash);
                            throw col_no_exist(table2, p_colname);
                        }*/
                    }
                    if(!is_quiet){
                        p_col_temp.emplace_back(p_colname);
                    }
                    //col_ind.emplace_back(it->second.ind);
                    col_ind.emplace_back(index);
                }
                if(!is_quiet){
                    for(auto &i: p_col_temp){
                        cout<<i<<' ';
                    }
                    cout<<'\n';
                }
                // Function runs in table 2.
                int sum_row = 0;
                if(col2_index != re_table2.ind_coluumn){
                    re_table2.join_help(col2_index);  // Create the temporary hash table
                }

                for(int i = 0; i < (int)re_table1.data.size(); ++i){
                    sum_row += re_table2.join(re_table1.data[i], col_ind, col_belong, is_quiet, col2_index, col1_index);
                }
                re_table2.tem_for_join.clear();
                cout<<"Printed "<<sum_row<<" rows from joining "<<table1<<" to "<<table2<<'\n';
                break;
            }
            case 'R':
            {
                cin>>tablename;
                cin.get();
                const auto& it = table_Map.find(tablename);
                if(it == table_Map.end()){
                    // ERROR!
                    throw table_no_exist(tablename);
                }
                Table_& re_table = it->second;
                /*
                const int& de = it->second;
                for(auto &i : table_map){ // modify the map when one table is deleted.
                    if(i.second>de){
                        --i.second;
                    }
                }*/
                re_table.hash_.clear();
                re_table.bst_.clear();
                table_Map.erase(it);
                /*
                auto it2 = table_vec.begin();
                for(int i = 0; i < de; ++i){
                    ++it2;
                }
                table_vec.erase(it2);
                table_map.erase(tablename);*/
                cout<<"Table "<<tablename<<" deleted\n";
                break;
            }
            default:
                throw wrong_command();
        }

    }while(command!="QUIT");
}

int Table_::Delete(const TableEntry& tbe,char oper, int ind) {
    int num = 0;
    switch (oper) {
        case '=':
        {
            auto it3 = remove_if(data.begin(), data.end(), Eq(move(tbe), ind));
            num = (int)(data.end() - it3);
            data.erase(it3, data.end()); // Whether we should erase!!!???
            break;
        }
        case '<':
        {
            auto it3 = remove_if(data.begin(), data.end(), Lt(move(tbe), ind));
            num = (int)(data.end() - it3);
            data.erase(it3, data.end()); // Whether we should erase!!!???
            break;
        }
        case '>':
        {
            auto it3 = remove_if(data.begin(), data.end(), Gt(move(tbe), ind));
            num = (int)(data.end() - it3);
            data.erase(it3, data.end()); // Whether we should erase!!!???
            break;
        }
        default:;
    }
    return num;
}

void Table_::generate_index(int col_index) {
    switch(index_type){
        case 'h':
        {
            hash_.clear();
            bst_.clear();
            for(int i = 0; i < (int)data.size(); ++i){
                TableEntry tempp(data[i][col_index]);
                auto it = hash_.find(tempp);
                if(it == hash_.end()){
                    vector<int> temp;
                    temp.emplace_back(i);
                    hash_.emplace(data[i][col_index],temp);
                }
                else{
                    it->second.emplace_back(i);
                }
            }
            break;
        }
        case 'b':
        {
            hash_.clear();
            bst_.clear();
            for(int i = 0; i < (int)data.size(); ++i){
                auto it = bst_.find(data[i][col_index]);
                if(it == bst_.end()){
                    vector<int> temp;
                    temp.emplace_back(i);
                    bst_.emplace(data[i][col_index],temp);
                }
                else{
                    it->second.emplace_back(i);
                }
            }
            break;
        }
        default:;
    }
}

void Table_::print(bool is_q) {
    int num;
    string p_colname, trash;
    cin >> num;
    //vector<int> col_ind;
    //vector<string> col_temp;

    vector<int> col_indices;
    for (int i = 0; i < num; i++) {
        bool found = false;
        cin >> p_colname;
        for (int j = 0; j < (int)col_info.size(); ++j) {
            if (col_info[j] == p_colname) {
                col_indices.push_back(j);
                found = true;
            }
        }
        if (!found) {
            // ERROR!!!
            getline(cin,trash);
            throw col_no_exist(name, p_colname);
        }
        //sort(indices.begin(), indices.end());
    }

    /*for(int i = 0; i < num; ++i){
        cin>>p_colname;
        auto it = info.find(p_colname);
        if(it == info.end()){
            //ERROR!
            getline(cin,trash);
            throw col_no_exist(name, p_colname);
        }

        if(!is_q){
            col_temp.emplace_back(p_colname);
        }
        col_ind.emplace_back(it->second.ind);
    }*/
    string judge;
    cin >> judge;
    switch(judge[0]){
        case 'A':
        {
            if(!is_q){
                for(auto &i: col_indices){
                //for(auto &i: col_temp){
                    //cout<<i<<' ';
                    cout<<col_info[i]<<' ';
                }
                cout<<'\n';
                for(auto &i:data){
                    for(int j = 0; j < num; ++j){
                        //cout<< i[col_ind[j]]<<' ';
                        cout<<i[col_indices[j]]<<' ';
                    }
                    cout<<'\n';
                }
            }
            cout<<"Printed "<<data.size()<<" matching rows from "<<name<<'\n';
            break;
        }
        case 'W':
        {
            string obj_col;
            char oper;
            cin>>obj_col>>oper;
            int ind = -1;
            for (int i = 0; i < (int)col_info.size(); i++)
                if (col_info[i] == obj_col) {
                    ind = i;
                    break;
                }
            if (ind == -1) {
                getline(cin,trash);
                throw col_no_exist(name, obj_col);
            }

            /*auto it2 = info.find(obj_col);
            if(it2 == info.end()){
                //ERROR!
                getline(cin,judge);
                throw col_no_exist(name, obj_col);
            }*/

            if(!is_q){
                for(auto &i: col_indices){
                    //for(auto &i: col_temp){
                    //cout<<i<<' ';
                    cout<<col_info[i]<<' ';
                }
                cout<<'\n';
            }
            const EntryType& typ = col_typ[ind];
            //int ind = it2->second.ind;
            string data0;
            double data1;
            int data2;
            bool data3;
            switch (typ) {
                case EntryType ::String: { // string
                    cin >> data0;
                    TableEntry tbe(data0);
                    print_help(is_q, tbe, oper, col_indices, ind);
                    break;
                }
                case EntryType ::Double: // double
                {
                    cin >> data1;
                    TableEntry tbe(data1);
                    print_help(is_q, tbe, oper, col_indices, ind);
                    break;
                }
                case EntryType ::Int: // int
                {
                    cin >> data2;
                    TableEntry tbe(data2);
                    print_help(is_q, tbe, oper, col_indices, ind);
                    break;
                }
                case EntryType ::Bool: // bool
                {
                    cin >> data3;
                    TableEntry tbe(data3);
                    print_help(is_q, tbe, oper, col_indices, ind);
                    break;
                }
                default:;
            }
        }
    }
}

void Table_::print_help(bool is_q, const TableEntry& tbe, char oper, vector<int>& col_ind, int obj_col) {
    vector<int> row_ind;
    switch (oper) {
        case '=': {
            if(obj_col == ind_coluumn){ // if conditional
                switch (index_type) {
                    case 'h': {
                        auto it3 = hash_.find(tbe);
                        if (it3 == hash_.end()) {// Empty
                        } else {
                            row_ind = it3->second;
                        }
                        break;
                    }
                    case 'b': {
                        auto it3 = bst_.find(tbe);
                        if (it3 == bst_.end()) {// Empty
                        } else {
                            row_ind = it3->second;
                        }
                        break;
                    }
                    default:{
                        for(int i = 0; i < (int)data.size(); ++i){
                            if(data[i][obj_col] == tbe){
                                row_ind.emplace_back(i);
                            }
                        }
                    }
                }
            }
            else{
                for(int i = 0; i < (int)data.size(); ++i){
                    if(data[i][obj_col] == tbe){
                        row_ind.emplace_back(i);
                    }
                }
            }
            break;
        }
        case '<':
        {
            if(obj_col == ind_coluumn){ // if conditional
                switch (index_type) {
                    case 'b': {
                        auto it3 = bst_.lower_bound(tbe);
                        for(auto i = bst_.begin(); i != it3; ++i){
                            for(int j = 0; j < (int)i->second.size(); ++j){
                                row_ind.emplace_back(i->second[j]);
                            }
                        }
                        break;
                    }
                    default:{
                        for(int i = 0; i < (int)data.size(); ++i){
                            if(data[i][obj_col] < tbe){
                                row_ind.emplace_back(i);
                            }
                        }
                    }
                }
            }
            else{
                for(int i = 0; i < (int)data.size(); ++i){
                    if(data[i][obj_col] < tbe){
                        row_ind.emplace_back(i);
                    }
                }
            }
            break;
        }
        case '>':
        {
            if(obj_col == ind_coluumn){ // if conditional
                switch (index_type) {
                    case 'b': {
                        auto it3 = bst_.upper_bound(tbe);
                        for(auto i = it3; i != bst_.end(); ++i){
                            for(int j = 0; j < (int)i->second.size(); ++j){
                                row_ind.emplace_back(i->second[j]);
                            }
                        }
                        break;
                    }
                    default:{
                        for(int i = 0; i < (int)data.size(); ++i){
                            if(data[i][obj_col] > tbe){
                                row_ind.emplace_back(i);
                            }
                        }
                    }
                }
            }
            else{
                for(int i = 0; i < (int)data.size(); ++i){
                    if(data[i][obj_col] > tbe){
                        row_ind.emplace_back(i);
                    }
                }
            }
            break;
        }
        default:;
            break;
    }

    // Output
    if(!is_q){
        for(auto &i:row_ind){
            for(auto &j:col_ind){
                cout<<data[i][j]<<' ';
            }
            cout<<'\n';
        }
    }
    cout<<"Printed "<<row_ind.size()<<" matching rows from "<<name<<'\n';

}

int Table_::join(vector<TableEntry> &obj, vector<int> &col_ind, vector<int> &col_belong, bool is_q, int obj_col_self, int obj_col_others) {
    int cnt = 0;
    if(obj_col_self == ind_coluumn){
        switch(index_type){
            case 'h':
            {
                auto it = hash_.find(obj[obj_col_others]);
                if(it == hash_.end()){} // no matches.
                else{
                    for(int i = 0; i < (int)it->second.size(); ++i){
                        for(int j = 0; j < (int)col_belong.size(); ++j){
                            if(!is_q){
                                switch(col_belong[j]){
                                    case 1:
                                    {
                                        cout<<obj[col_ind[j]]<<' ';
                                        break;
                                    }
                                    default:
                                    {
                                        cout<<data[it->second[i]][col_ind[j]]<<' ';
                                    }
                                }
                            }
                        }
                        if(!is_q){cout<<'\n';}
                        ++cnt;
                    }
                }
                break;
            }
            case 'b':
            {
                auto it = bst_.find(obj[obj_col_others]);
                if(it == bst_.end()){} // no matches.
                else{
                    for(int i = 0; i < (int)it->second.size(); ++i){
                        for(int j = 0; j < (int)col_belong.size(); ++j){
                            if(!is_q){
                                switch(col_belong[j]){
                                    case 1:
                                    {
                                        cout<<obj[col_ind[j]]<<' ';
                                        break;
                                    }
                                    default:
                                    {
                                        cout<<data[it->second[i]][col_ind[j]]<<' ';
                                    }
                                }
                            }
                        }
                        if(!is_q){cout<<'\n';}
                        ++cnt;
                    }
                }
                break;
            }
            default:;
        }
    }
    else{ // normal case, using tem_hash.
        auto it = tem_for_join.find(obj[obj_col_others]);
        if(it == tem_for_join.end()){} // no matches.
        else{
            for(int i = 0; i < (int)it->second.size(); ++i){
                for(int j = 0; j < (int)col_belong.size(); ++j){
                    if(!is_q){
                        switch(col_belong[j]){
                            case 1:
                            {
                                cout<<obj[col_ind[j]]<<' ';
                                break;
                            }
                            default:
                            {
                                cout<<data[it->second[i]][col_ind[j]]<<' ';
                            }
                        }
                    }
                }
                if(!is_q){cout<<'\n';}
                ++cnt;
            }
        }
    }
    return cnt;
}

void Table_::join_help(int obj_col) {
    tem_for_join.clear();
    for(int i = 0; i < (int)data.size(); ++i){
        auto it = tem_for_join.find(data[i][obj_col]);
        if(it == tem_for_join.end()){
            vector<int> temp;
            temp.emplace_back(i);
            tem_for_join.emplace(data[i][obj_col], temp);
        }
        else{
            it->second.emplace_back(i);
        }
    }
}
